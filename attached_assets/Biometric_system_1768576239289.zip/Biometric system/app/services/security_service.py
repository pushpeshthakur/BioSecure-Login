import jwt
import datetime
from app.config.security import SecurityConfig

class SecurityService:
    def generate_token(self, user_id):
        payload = {
            'user_id': user_id,
            'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=1)
        }
        token = jwt.encode(payload, SecurityConfig.SECRET_KEY, algorithm='HS256')
        return token

    def verify_token(self, token):
        try:
            payload = jwt.decode(token, SecurityConfig.SECRET_KEY, algorithms=['HS256'])
            return payload['user_id']
        except jwt.ExpiredSignatureError:
            return None
        except jwt.InvalidTokenError:
            return None
