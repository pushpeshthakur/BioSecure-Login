const API_BASE_URL = 'http://localhost:5000/api/v1';

async function enrollUser(username, email, faceImageBase64, voiceAudioBase64) {
    const response = await fetch(`${API_BASE_URL}/enroll/`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            username: username,
            email: email,
            face_image: faceImageBase64,
            voice_audio: voiceAudioBase64,
        }),
    });
    return response.json();
}

async function authenticateUser(faceImageBase64, voiceAudioBase64) {
    const response = await fetch(`${API_BASE_URL}/auth/authenticate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            face_image: faceImageBase64,
            voice_audio: voiceAudioBase64,
        }),
    });
    return response.json();
}
