# Any face image preprocessing utility functions here

def normalize_face_image(image):
    """
    Normalize the PIL image for FaceNet requirements if needed
    """
    # Example placeholder; facenet_pytorch handles most preprocessing internally
    return image
