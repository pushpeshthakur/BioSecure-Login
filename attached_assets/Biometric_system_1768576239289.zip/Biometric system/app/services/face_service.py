from app.models.face_model.facenet_handler import FaceNetHandler

class FaceService:
    def __init__(self):
        self.handler = FaceNetHandler()
    
    def process_face(self, img):
        face = self.handler.extract_face(img)
        if face is None:
            return None
        emb = self.handler.get_embedding(face)
        return emb
