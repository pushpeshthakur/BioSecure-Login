from pydantic import BaseModel

class AuthenticateRequest(BaseModel):
    face_image: str  # base64 string
    voice_audio: str  # base64 string

class AuthenticateResponse(BaseModel):
    success: bool
    user_id: int = None
    username: str = None
    face_confidence: float = None
    voice_confidence: float = None
    error: str = None
