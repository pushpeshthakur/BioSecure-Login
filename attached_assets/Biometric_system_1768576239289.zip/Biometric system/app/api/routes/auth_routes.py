from flask import Blueprint, request, jsonify
from app.services.authentication_service import AuthenticationService
import base64
from io import BytesIO
from PIL import Image
import numpy as np

auth_bp = Blueprint('auth', __name__, url_prefix='/api/v1/auth')
auth_service = AuthenticationService()

def decode_image(image_b64):
    image_bytes = base64.b64decode(image_b64)
    image = Image.open(BytesIO(image_bytes)).convert('RGB')
    return np.array(image)

def decode_audio(audio_b64):
    return base64.b64decode(audio_b64)

@auth_bp.route('/authenticate', methods=['POST'])
def authenticate():
    data = request.json
    if not data or 'face_image' not in data or 'voice_audio' not in data:
        return jsonify({'success': False, 'error': 'Face image and voice audio required'}), 400

    face_img = decode_image(data['face_image'])
    voice_audio = decode_audio(data['voice_audio'])

    result = auth_service.authenticate(face_img, voice_audio)

    if result['success']:
        return jsonify(result), 200
    else:
        return jsonify(result), 401
