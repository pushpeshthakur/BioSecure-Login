class BiometricAuthSDK {
    constructor(apiUrl) {
        this.apiUrl = apiUrl;
    }

    async authenticate(faceImageBase64, voiceAudioBase64) {
        const response = await fetch(`${this.apiUrl}/authenticate`, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                face_image: faceImageBase64,
                voice_audio: voiceAudioBase64,
            }),
        });
        return response.json();
    }
}

// Export for use in projects
export default BiometricAuthSDK;
