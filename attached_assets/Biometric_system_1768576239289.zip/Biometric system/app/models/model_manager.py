from app.models.face_model.facenet_handler import FaceNetHandler
from app.models.voice_model.wav2vec2_handler import Wav2Vec2Handler

class ModelManager:
    def __init__(self, device='cpu'):
        self.face_model = FaceNetHandler(device=device)
        self.voice_model = Wav2Vec2Handler(device=device)

    def get_face_embedding(self, image):
        return self.face_model.extract_face(image), self.face_model.get_embedding(image)

    def get_voice_embedding(self, audio):
        return self.voice_model.get_embedding(audio)
