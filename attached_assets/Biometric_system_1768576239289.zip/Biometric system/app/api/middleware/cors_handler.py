# CORS handled by flask_cors extension in app/__init__.py
