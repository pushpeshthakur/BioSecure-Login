from app.database.models import User
from app.config.database import db

class UserRepository:
    def get_by_id(self, user_id):
        return User.query.get(user_id)

    def get_by_username(self, username):
        return User.query.filter_by(username=username).first()

    def add(self, user):
        db.session.add(user)
        db.session.commit()
        return user

    def list_all(self):
        return User.query.all()
