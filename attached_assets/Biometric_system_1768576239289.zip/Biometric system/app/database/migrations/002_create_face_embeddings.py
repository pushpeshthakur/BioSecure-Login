from alembic import op
import sqlalchemy as sa

def upgrade():
    op.create_table(
        'face_embeddings',
        sa.Column('id', sa.Integer, primary_key=True),
        sa.Column('user_id', sa.Integer, nullable=False),
        sa.Column('embedding', sa.Text, nullable=False),
        sa.Column('confidence', sa.Float, nullable=False),
        sa.Column('created_at', sa.DateTime, server_default=sa.func.now()),
        sa.Column('is_primary', sa.Boolean, default=True)
    )

def downgrade():
    op.drop_table('face_embeddings')
