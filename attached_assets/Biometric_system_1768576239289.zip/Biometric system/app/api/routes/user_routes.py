from flask import Blueprint, jsonify
from app.database.repositories.user_repository import UserRepository

user_bp = Blueprint('user', __name__, url_prefix='/api/v1/users')
user_repo = UserRepository()

@user_bp.route('/', methods=['GET'])
def get_users():
    users = user_repo.list_all()
    return jsonify([{'id': u.id, 'username': u.username, 'email': u.email} for u in users])
