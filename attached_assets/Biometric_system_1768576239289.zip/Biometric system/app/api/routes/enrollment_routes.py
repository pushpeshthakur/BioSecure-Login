from flask import Blueprint, request, jsonify
from app.services.enrollment_service import EnrollmentService
import base64
from io import BytesIO
from PIL import Image
import numpy as np

enroll_bp = Blueprint('enroll', __name__, url_prefix='/api/v1/enroll')
enroll_service = EnrollmentService()

def decode_image(image_b64):
    image_bytes = base64.b64decode(image_b64)
    image = Image.open(BytesIO(image_bytes)).convert('RGB')
    return np.array(image)

@enroll_bp.route('/', methods=['POST'])
def enroll_user():
    data = request.json
    username = data.get('username')
    email = data.get('email')
    face_img_b64 = data.get('face_image')
    voice_audio_b64 = data.get('voice_audio')

    if not all([username, email, face_img_b64, voice_audio_b64]):
        return jsonify({'success': False, 'error': 'Missing fields'}), 400

    try:
        face_img = decode_image(face_img_b64)
        voice_audio = base64.b64decode(voice_audio_b64)

        # Call enrollment service to save user + embeddings
        result = enroll_service.enroll_user(username, email, face_img, voice_audio)
        if result.get('success'):
            return jsonify(result), 200
        else:
            return jsonify(result), 400
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500
