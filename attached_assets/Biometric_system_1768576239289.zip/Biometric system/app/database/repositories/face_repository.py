from app.database.models import FaceEmbedding
from app.config.database import db

class FaceRepository:
    def get_all_embeddings(self):
        return FaceEmbedding.query.all()

    def add_embedding(self, embedding):
        db.session.add(embedding)
        db.session.commit()
        return embedding

    def get_by_user_id(self, user_id):
        return FaceEmbedding.query.filter_by(user_id=user_id).all()
