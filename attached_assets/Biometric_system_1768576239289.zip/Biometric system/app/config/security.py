import os

class SecurityConfig:
    SECRET_KEY = os.getenv('SECRET_KEY', 'default-secret-key')
    ENCRYPTION_KEY = os.getenv('ENCRYPTION_KEY')  # Used by EncryptionManager
