# Audio handling utilities

import soundfile as sf

def load_audio_file(filepath, sample_rate=16000):
    audio, sr = sf.read(filepath)
    if sr != sample_rate:
        import librosa
        audio = librosa.resample(audio, orig_sr=sr, target_sr=sample_rate)
    return audio
