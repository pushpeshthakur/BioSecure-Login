from app.database.models import VoiceEmbedding
from app.config.database import db

class VoiceRepository:
    def get_by_user_id(self, user_id):
        return VoiceEmbedding.query.filter_by(user_id=user_id).all()

    def add_embedding(self, embedding):
        db.session.add(embedding)
        db.session.commit()
        return embedding
