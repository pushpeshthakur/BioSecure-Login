import torch
from facenet_pytorch import MTCNN, InceptionResnetV1
import numpy as np
from PIL import Image

class FaceNetHandler:
    def __init__(self, device='cpu'):
        self.device = torch.device(device)
        self.mtcnn = MTCNN(image_size=160, margin=0, min_face_size=20, device=self.device)
        self.model = InceptionResnetV1(pretrained='vggface2').eval().to(self.device)

    def extract_face(self, image):
        if isinstance(image, np.ndarray):
            image = Image.fromarray(image)
        face = self.mtcnn(image)
        return face

    def get_embedding(self, face_tensor):
        if face_tensor is None:
            return None
        face_tensor = face_tensor.unsqueeze(0).to(self.device)
        with torch.no_grad():
            embedding = self.model(face_tensor)
        return embedding.cpu().numpy().flatten()

    def compare_embeddings(self, emb1, emb2, threshold=0.6):
        similarity = np.dot(emb1, emb2)
        return similarity > threshold, similarity
