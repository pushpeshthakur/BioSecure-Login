# Biometric Authentication SDK Documentation

## Installation

Include the SDK via script tag or import in your project:

