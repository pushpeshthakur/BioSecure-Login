# Voice preprocessing utilities (e.g., noise reduction, normalization)

import numpy as np

def normalize_audio(audio_signal):
    max_val = np.max(np.abs(audio_signal))
    if max_val > 0:
        return audio_signal / max_val
    return audio_signal
