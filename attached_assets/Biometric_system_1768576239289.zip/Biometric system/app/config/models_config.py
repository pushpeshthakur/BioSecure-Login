# Configuration related to model parameters and hyperparameters

class ModelConfig:
    FACE_IMAGE_SIZE = 160
    FACE_THRESHOLD = 0.6
    VOICE_THRESHOLD = 0.7
    VOICE_SAMPLE_RATE = 16000
