# Could handle specialized matching logic if needed
# For simplicity, you can keep matching inside AuthenticationService or extend this as needed.
