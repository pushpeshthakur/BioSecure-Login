from app.models.voice_model.wav2vec2_handler import Wav2Vec2Handler

class VoiceService:
    def __init__(self):
        self.handler = Wav2Vec2Handler()
    
    def process_voice(self, audio):
        emb = self.handler.get_embedding(audio)
        return emb
