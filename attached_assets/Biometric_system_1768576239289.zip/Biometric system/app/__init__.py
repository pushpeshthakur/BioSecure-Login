from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from app.config.database import db
from app.api.routes.auth_routes import auth_bp
from app.api.routes.enrollment_routes import enroll_bp

def create_app():
    app = Flask(__name__)
    app.config.from_object('config.Config')

    # Initialize database with app
    db.init_app(app)

    # Enable CORS for cross-origin requests if needed
    CORS(app)

    # Register API blueprints
    app.register_blueprint(auth_bp)     # Authentication routes
    app.register_blueprint(enroll_bp)   # Enrollment routes

    return app
