const video = document.getElementById('video');
const captureFaceBtn = document.getElementById('captureFaceBtn');

let canvas, context;
let faceImageBase64 = null;

async function startCamera() {
    try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        video.srcObject = stream;
    } catch (err) {
        alert('Error accessing camera: ' + err.message);
    }
}

function captureFace() {
    if (!canvas) {
        canvas = document.createElement('canvas');
        context = canvas.getContext('2d');
    }
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    context.drawImage(video, 0, 0, canvas.width, canvas.height);
    faceImageBase64 = canvas.toDataURL('image/jpeg');
    alert('Face image captured!');
}

captureFaceBtn.addEventListener('click', captureFace);

startCamera();

function getFaceImage() {
    return faceImageBase64;
}
