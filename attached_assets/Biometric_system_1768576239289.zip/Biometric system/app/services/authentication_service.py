import json
from app.models.face_model.facenet_handler import FaceNetHandler
from app.models.voice_model.wav2vec2_handler import Wav2Vec2Handler
from app.database.models import User, FaceEmbedding, VoiceEmbedding
from app.config.database import db

class AuthenticationService:
    def __init__(self):
        self.face_handler = FaceNetHandler()
        self.voice_handler = Wav2Vec2Handler()

    def authenticate(self, face_image, voice_audio):
        face = self.face_handler.extract_face(face_image)
        if face is None:
            return {'success': False, 'error': 'No face detected'}

        face_emb = self.face_handler.get_embedding(face)
        voice_emb = self.voice_handler.get_embedding(voice_audio)

        # Query all face embeddings from database
        faces = FaceEmbedding.query.all()
        best_user_id = None
        best_conf = 0

        for face_record in faces:
            stored_emb = json.loads(face_record.embedding)
            match, conf = self.face_handler.compare(face_emb, stored_emb)
            if match and conf > best_conf:
                best_conf = conf
                best_user_id = face_record.user_id

        if best_user_id is None:
            return {'success': False, 'error': 'Face not recognized'}

        voices = VoiceEmbedding.query.filter_by(user_id=best_user_id).all()
        voice_match = False
        voice_conf = 0

        for voice_record in voices:
            stored_emb = json.loads(voice_record.embedding)
            match, conf = self.voice_handler.compare(voice_emb, stored_emb)
            if match and conf > voice_conf:
                voice_conf = conf
                voice_match = True

        if voice_match:
            user = User.query.get(best_user_id)
            return {'success': True, 'user_id': user.id, 'username': user.username, 'face_confidence': best_conf, 'voice_confidence': voice_conf}
        else:
            return {'success': False, 'error': 'Voice verification failed'}
