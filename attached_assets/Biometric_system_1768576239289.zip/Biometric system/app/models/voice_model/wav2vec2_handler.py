import torch
from transformers import Wav2Vec2Processor, Wav2Vec2Model
import numpy as np
import librosa

class Wav2Vec2Handler:
    def __init__(self, device='cpu'):
        self.device = torch.device(device)
        self.processor = Wav2Vec2Processor.from_pretrained('facebook/wav2vec2-base')
        self.model = Wav2Vec2Model.from_pretrained('facebook/wav2vec2-base').to(self.device)
        self.model.eval()

    def get_embedding(self, audio, sample_rate=16000):
        if isinstance(audio, str):
            audio_data, _ = librosa.load(audio, sr=sample_rate)
        else:  # Assume numpy array
            audio_data = audio
        
        inputs = self.processor(audio_data, sampling_rate=sample_rate, return_tensors="pt", padding=True).to(self.device)

        with torch.no_grad():
            outputs = self.model(**inputs)

        embedding = torch.nn.functional.normalize(outputs.last_hidden_state.mean(dim=1), p=2, dim=1)
        return embedding.cpu().numpy().flatten()

    def compare_embeddings(self, emb1, emb2, threshold=0.7):
        similarity = np.dot(emb1, emb2)
        return similarity > threshold, similarity
