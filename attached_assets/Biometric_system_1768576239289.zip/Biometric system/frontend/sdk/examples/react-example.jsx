import React, { useState } from 'react';
import BiometricAuthSDK from '../biometric-auth-sdk.js';

const sdk = new BiometricAuthSDK('http://localhost:5000/api/v1/auth');

export default function BiometricLogin() {
  const [status, setStatus] = useState('');

  const authenticate = async () => {
    const faceImage = ''; // base64 face data
    const voiceAudio = ''; // base64 voice data
    const res = await sdk.authenticate(faceImage, voiceAudio);
    if(res.success) setStatus(`Welcome, ${res.username}`);
    else setStatus(`Failed: ${res.error}`);
  };

  return (
    <div>
      <button onClick={authenticate}>Authenticate</button>
      <p>{status}</p>
    </div>
  );
}
