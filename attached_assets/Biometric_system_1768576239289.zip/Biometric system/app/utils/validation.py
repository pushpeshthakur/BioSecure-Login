from PIL import Image
import io

def validate_image(image_bytes):
    try:
        image = Image.open(io.BytesIO(image_bytes))
        image.verify()
        return True
    except Exception:
        return False

def validate_audio(audio_bytes):
    # Basic check: non-empty bytes
    return len(audio_bytes) > 100
