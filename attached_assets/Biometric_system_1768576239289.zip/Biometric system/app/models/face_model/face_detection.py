from facenet_pytorch import MTCNN

class FaceDetector:
    def __init__(self, device='cpu'):
        self.mtcnn = MTCNN(image_size=160, margin=0, min_face_size=20, device=device)

    def detect(self, image):
        """
        Returns bounding boxes or cropped faces detected in the image
        """
        boxes, probs = self.mtcnn.detect(image)
        return boxes, probs
