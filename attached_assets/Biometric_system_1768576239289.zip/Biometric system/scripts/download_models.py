import os
import torch
from facenet_pytorch import InceptionResnetV1, MTCNN
from transformers import Wav2Vec2Model, Wav2Vec2Processor

def download_face_models():
    """Download FaceNet models"""
    print("Downloading FaceNet models...")
    
    # Create directory
    os.makedirs('app/models/face_model/weights', exist_ok=True)
    
    # Download VGGFace2 model (Recommended)
    model_vgg = InceptionResnetV1(pretrained='vggface2').eval()
    torch.save(model_vgg.state_dict(), 'app/models/face_model/weights/vggface2.pt')
    
    # Download MTCNN for face detection
    mtcnn = MTCNN(image_size=160, margin=0, min_face_size=20)
    
    print("✅ FaceNet models downloaded successfully!")

def download_voice_models():
    """Download Wav2Vec2 models"""
    print("Downloading Wav2Vec2 models...")
    
    # Create directory
    os.makedirs('app/models/voice_model/weights', exist_ok=True)
    
    # Download Wav2Vec2-base model
    model = Wav2Vec2Model.from_pretrained('facebook/wav2vec2-base')
    processor = Wav2Vec2Processor.from_pretrained('facebook/wav2vec2-base')
    
    # Save models locally
    model.save_pretrained('app/models/voice_model/weights/wav2vec2-base')
    processor.save_pretrained('app/models/voice_model/weights/wav2vec2-base')
    
    print("✅ Wav2Vec2 models downloaded successfully!")

def main():
    print("🚀 Starting model downloads...")
    
    try:
        download_face_models()
        download_voice_models()
        
        print("\n🎉 All models downloaded successfully!")
        print("\nModel locations:")
        print("📁 Face models: app/models/face_model/weights/")
        print("📁 Voice models: app/models/voice_model/weights/wav2vec2-base/")
        
    except Exception as e:
        print(f"❌ Error downloading models: {e}")

if __name__ == "__main__":
    main()
