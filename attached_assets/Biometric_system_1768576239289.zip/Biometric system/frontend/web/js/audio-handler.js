const voiceInput = document.getElementById('voiceInput');
let voiceAudioBase64 = null;

voiceInput.addEventListener('change', () => {
    const file = voiceInput.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = function (e) {
        voiceAudioBase64 = e.target.result.split(',')[1]; // remove mime type
        alert('Voice audio loaded!');
    };
    reader.readAsDataURL(file);
});

function getVoiceAudio() {
    return voiceAudioBase64;
}
