import json
from app.config.database import db
from app.database.models import User, FaceEmbedding, VoiceEmbedding
from app.models.face_model.facenet_handler import FaceNetHandler
from app.models.voice_model.wav2vec2_handler import Wav2Vec2Handler

class EnrollmentService:
    def __init__(self):
        self.user_model = User
        self.face_model = FaceNetHandler()
        self.voice_model = Wav2Vec2Handler()

    def enroll_user(self, username, email, face_image, voice_audio):
        # Check if user exists
        existing = self.user_model.query.filter_by(username=username).first()
        if existing:
            return {'success': False, 'error': 'User already exists'}

        # Extract face embedding
        face_tensor = self.face_model.extract_face(face_image)
        if face_tensor is None:
            return {'success': False, 'error': 'No face detected in image'}
        face_embedding = self.face_model.get_embedding(face_tensor)

        # Extract voice embedding
        voice_embedding = self.voice_model.get_embedding(voice_audio)

        # Create user
        user = User(username=username, email=email)
        db.session.add(user)
        db.session.commit()

        # Save embeddings
        face_emb = FaceEmbedding(user_id=user.id,
                                 embedding=json.dumps(face_embedding.tolist()),
                                 confidence=1.0,
                                 is_primary=True)
        voice_emb = VoiceEmbedding(user_id=user.id,
                                   embedding=json.dumps(voice_embedding.tolist()),
                                   confidence=1.0,
                                   is_primary=True)

        db.session.add(face_emb)
        db.session.add(voice_emb)
        db.session.commit()

        return {'success': True, 'user_id': user.id}
