const video = document.getElementById('video');
const captureFaceBtn = document.getElementById('captureFaceBtn');
const faceStatus = document.getElementById('faceStatus');

let canvas, context;
let faceImageBase64 = null;

// Start webcam
async function startCamera() {
    try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        video.srcObject = stream;
    } catch (err) {
        alert('Failed to access camera: ' + err.message);
    }
}
startCamera();

// Capture face image
function captureFace() {
    if (!canvas) {
        canvas = document.createElement('canvas');
        context = canvas.getContext('2d');
    }
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    context.drawImage(video, 0, 0, canvas.width, canvas.height);
    faceImageBase64 = canvas.toDataURL('image/jpeg');
    faceStatus.textContent = 'Face captured!';
}

captureFaceBtn.addEventListener('click', captureFace);

function getFaceImage() {
    return faceImageBase64;
}

// Voice input handled in separate audio-handler.js
